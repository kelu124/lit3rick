This directory contains standard, low-level C libraries with emphasis on
being independent and efficient.  They can be used by any port.
